Support
-------

**Python**:
  see http://www.python.org/community/

**PostgreSQL**:
  see http://www.postgresql.org/support/

**PyGreSQL**:
  Join `the PyGreSQL mailing list <https://mail.vex.net/mailman/listinfo.cgi/pygresql>`_
  if you need help regarding PyGreSQL.

  Please also send context diffs there, if you would like to proposes changes.

  Please note that messages to individual developers will generally not be
  answered directly.  All questions, comments and code changes must be
  submitted to the mailing list for peer review and archiving purposes.