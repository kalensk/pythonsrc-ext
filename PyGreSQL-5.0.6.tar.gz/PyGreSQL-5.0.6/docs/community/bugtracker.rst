Bug Tracker
-----------

We are using `Trac <http://trac.edgewall.org/>`_ as an issue tracker.

Track tickets are usually entered after discussion on the mailing list,
but you may also request an account for the issue tracker and add or
process tickets if you want to get more involved into the development
of the project. You can use the following links to get an overview:

* `PyGreSQL Issues Tracker <http://trac.pygresql.org:8000/pgtracker/>`_
* `Timeline with all changes <http://trac.pygresql.org:8000/pgtracker/timeline>`_
* `Roadmap of the project <http://trac.pygresql.org:8000/pgtracker/roadmap>`_
* `Lists of active tickets <http://trac.pygresql.org:8000/pgtracker/report>`_
* `PyGreSQL Trac browser <http://trac.pygresql.org:8000/pgtracker/browser/trunk>`_