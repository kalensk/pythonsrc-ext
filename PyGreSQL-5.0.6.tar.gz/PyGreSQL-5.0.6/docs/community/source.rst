Access to the source repository
-------------------------------

We are using a central `Subversion <https://subversion.apache.org/>`_
source code repository for PyGreSQL.

The current trunk of the repository can be checked out with the command::

    svn co svn://svn.pygresql.org/pygresql/trunk

You can also browse through the repository using the
`PyGreSQL Trac browser <http://trac.pygresql.org:8000/pgtracker/browser/trunk>`_.
